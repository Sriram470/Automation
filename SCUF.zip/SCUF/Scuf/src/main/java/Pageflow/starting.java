package Pageflow;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

public class starting {
	public static BasicFunction fun = new BasicFunction();

	WebDriver driver;
	ExtentReports extentreport;
	ExtentHtmlReporter htmlreport;
	ExtentTest test;

	@BeforeTest

	public void openchrome() throws AWTException {

		extentreport = new ExtentReports();

		htmlreport = new ExtentHtmlReporter("Reporter.html");

		extentreport.attachReporter(htmlreport);

		System.setProperty("webdriver.chrome.driver", "E:\\chromedriver\\chromedriver.exe");
		this.driver = new ChromeDriver();
		driver.get("https://digital.novactech.in/");
		driver.manage().window().maximize();
		extentreport.createTest("two wheeler loan");

		// driver.manage().deleteAllCookies();

	}

	@Test(priority = 0)

	public void flow() throws InterruptedException, IOException {
		driver.findElement(By.xpath("//*[@id=\"onloadPopup\"]/div/div/div/a")).click();
		System.out.println("popupclosed");

		driver.findElement(By.xpath("/html/body/section/div[1]/div[2]/div/ul/li[1]/a")).click();
		System.out.println("icon clicked");

		driver.findElement(By.xpath("/html/body/div[6]/div/div[2]/div/div/div/div/div[2]/button")).click();
		System.out.println("page1 failed");
		
		Thread.sleep(4000);
		fun.capturescreenshot(driver);

		Thread.sleep(3000);

	}

	@Test(enabled = false)

	public void happyflow() throws InterruptedException {

		Thread.sleep(2000);
		driver.findElement(By.id("AFName")).sendKeys("Sriram k");
		driver.findElement(By.id("AFMobile")).sendKeys("8098070510");
		driver.findElement(By.id("AFEmail")).sendKeys("sriramkumar470@gmail.com");
		driver.findElement(By.id("AFDob")).sendKeys("31-01-1998");
		driver.findElement(By.id("AFGenderMale")).click();
		driver.findElement(By.id("AFMaritalSingle")).click();
		driver.findElement(By.id("AFLiveLnStusChkNo")).click();
		driver.findElement(By.id("AFPAN")).sendKeys("LWRPS3091M ");
		driver.findElement(By.id("AFResidencePincode")).sendKeys("632002");

		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,250)", "");
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id=\"qkPersonaldetsubmitForm\"]/div[8]/div[1]/div/label/span")).click();

		driver.findElement(By.xpath("//*[@id=\"qkPersonaldetsubmitForm\"]/div[8]/div[2]/div/button")).click();

		Thread.sleep(2000);
		driver.findElement(By.id("AFotpCode")).sendKeys("11111");

		driver.findElement(By.xpath("//*[@id=\"exampleModal\"]/div/div/div/div/div[2]/div/div[3]/button")).click();
		Thread.sleep(20000);

		Select dropdown = new Select(driver.findElement(By.id("AFManufacturer")));
		dropdown.selectByValue("HERO ELECTRIC");

		Select mfmodel = new Select(driver.findElement(By.id("AFModel")));
		mfmodel.selectByValue("OPTIMA LA");

		Thread.sleep(1500);

		Select Tenure = new Select(driver.findElement(By.id("AFTenure")));
		Tenure.selectByValue("18");

		Thread.sleep(1500);

		Select AFTimeTaken = new Select(driver.findElement(By.id("AFTimeTaken")));
		AFTimeTaken.selectByValue("immediate");

		Thread.sleep(1500);

		Select ResidentType = new Select(driver.findElement(By.id("AFResidentType")));
		ResidentType.selectByValue("Ownedbyselforspouse");

		Thread.sleep(1500);

		Select Currentlvgresidence = new Select(driver.findElement(By.id("AFCurrentlvgresidence")));
		Currentlvgresidence.selectByValue("bwn3to5");

		driver.findElement(By.xpath("//*[@id=\"ResidentialdetsubmitForm\"]/div[4]/div[2]/button")).click();

		Thread.sleep(7000);

		Select EmploymentType = new Select(driver.findElement(By.id("AFEmploymentType")));
		EmploymentType.selectByValue("Salaried");

		Thread.sleep(2000);

		Select OrgType = new Select(driver.findElement(By.id("AFOrgType")));
		OrgType.selectByValue("Private");

		Thread.sleep(2000);

		driver.findElement(By.id("AFNetMonthSalary")).sendKeys("50001");

		Thread.sleep(2000);

		driver.findElement(By.id("AFCompanyName")).sendKeys("control print limited");

		Thread.sleep(2000);

		Select noofyears = new Select(driver.findElement(By.id("AFNoofyearsworkCurtEmp")));
		noofyears.selectByValue("5");

		Thread.sleep(2000);

		Select totalworkexp = new Select(driver.findElement(By.id("AFTotalWorkExperience")));
		totalworkexp.selectByValue("5");

		Thread.sleep(2000);

		driver.findElement(By.id("AFExistingEmiCmts")).sendKeys("0");

		Thread.sleep(1500);

		JavascriptExecutor js3 = (JavascriptExecutor) driver;
		js3.executeScript("window.scrollBy(0,150)", "");

		driver.findElement(By.id("PaymentDPminimum")).click();

		Thread.sleep(1500);

		WebElement downpay = driver.findElement(By.id("AFDownPayment"));
		String amount = downpay.getText();
		String dispamount = "";
		Assert.assertEquals(dispamount, amount);
		// Assert.assertEquals(actual, expected);

		Thread.sleep(1500);

		driver.findElement(By.xpath("//*[@id=\"EmployerdetsubmitForm\"]/div[8]/div[2]/button")).click();
		System.out.println("page navigated to bank details page ");

		Thread.sleep(10000);

		driver.findElement(By.id("incomeproof")).sendKeys("C:\\Users\\DELL\\Downloads\\statement.pdf");

	}

	@Test(priority = 1)

	public void BasicinfoPAGE1() throws IOException, InterruptedException {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,250)", "");

		driver.findElement(By.xpath("//*[@id=\"qkPersonaldetsubmitForm\"]/div[8]/div[2]/div/button")).click();
		System.out.println("needs to fill all the fields");

		// fun.capturescreenshot(driver);

		Thread.sleep(4000);
	}

	@Test(priority = 2)
	public void pag1PASS() throws IOException, InterruptedException, AWTException {

		Robot robo = new Robot();

		Actions actions = new Actions(driver);

		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(250,0)", "");

		// APPLICANT NAME

		driver.findElement(By.id("AFName")).sendKeys("Sriram k");
		System.out.println("mobilenumber");

		// MOBILE NUMBER

		driver.findElement(By.id("AFMobile")).sendKeys("80980705");
		robo.keyPress(KeyEvent.VK_TAB);
		robo.keyRelease(KeyEvent.VK_TAB);
		WebElement mobilenumber = driver.findElement(By.xpath("//*[@id=\"AFMobile-error\"]"));
		String validation1 = mobilenumber.getText();
		String verify1 = "Please enter a valid 10 digit mobile number";
		Assert.assertEquals(verify1, validation1);

		Thread.sleep(2000);

		driver.findElement(By.id("AFMobile")).clear();
		driver.findElement(By.id("AFMobile")).sendKeys("5685263254");
		robo.keyPress(KeyEvent.VK_TAB);
		robo.keyRelease(KeyEvent.VK_TAB);
		WebElement mobilenumber1 = driver.findElement(By.xpath("//*[@id=\"AFMobile-error\"]"));
		String validation2 = mobilenumber1.getText();
		String verify2 = "Please enter a valid 10 digit mobile number";
		Assert.assertEquals(verify2, validation2);

		Thread.sleep(2000);

		driver.findElement(By.id("AFMobile")).clear();
		driver.findElement(By.id("AFMobile")).sendKeys("02563524125");
		robo.keyPress(KeyEvent.VK_TAB);
		robo.keyRelease(KeyEvent.VK_TAB);
		WebElement mobilenumber2 = driver.findElement(By.xpath("//*[@id=\"AFMobile-error\"]"));
		String validation3 = mobilenumber2.getText();
		String verify3 = "Please enter a valid 10 digit mobile number";
		Assert.assertEquals(verify3, validation3);

		Thread.sleep(2000);

		driver.findElement(By.id("AFMobile")).clear();
		driver.findElement(By.id("AFMobile")).sendKeys("8098070510");
		System.out.println("mobilenumber");
		robo.keyPress(KeyEvent.VK_TAB);
		robo.keyRelease(KeyEvent.VK_TAB);

		// EMAIL id

		driver.findElement(By.id("AFEmail")).sendKeys("470070");
		robo.keyPress(KeyEvent.VK_TAB);
		robo.keyRelease(KeyEvent.VK_TAB);
		WebElement email = driver.findElement(By.id("AFEmail-error"));
		String mailvalidation1 = email.getText();
		String mailverify1 = "Please enter a valid email id";
		Assert.assertEquals(mailverify1, mailvalidation1);

		Thread.sleep(1500);

		driver.findElement(By.id("AFEmail")).clear();
		driver.findElement(By.id("AFEmail")).sendKeys("sriram k");
		robo.keyPress(KeyEvent.VK_TAB);
		robo.keyRelease(KeyEvent.VK_TAB);
		WebElement email1 = driver.findElement(By.id("AFEmail-error"));
		String mailvalidation2 = email1.getText();
		String mailverify2 = "Please enter a valid email id";
		Assert.assertEquals(mailverify2, mailvalidation2);

		Thread.sleep(1500);

		driver.findElement(By.id("AFEmail")).clear();
		driver.findElement(By.id("AFEmail")).sendKeys("sriramkumar.");
		robo.keyPress(KeyEvent.VK_TAB);
		robo.keyRelease(KeyEvent.VK_TAB);
		WebElement email2 = driver.findElement(By.id("AFEmail-error"));
		String mailvalidation3 = email2.getText();
		String mailverify3 = "Please enter a valid email id";
		Assert.assertEquals(mailverify3, mailvalidation3);

		Thread.sleep(1500);

		driver.findElement(By.id("AFEmail")).clear();
		driver.findElement(By.id("AFEmail")).sendKeys("sriramkumar470");
		robo.keyPress(KeyEvent.VK_TAB);
		robo.keyRelease(KeyEvent.VK_TAB);
		WebElement email3 = driver.findElement(By.id("AFEmail-error"));
		String mailvalidation4 = email3.getText();
		String mailverify4 = "Please enter a valid email id";
		Assert.assertEquals(mailverify4, mailvalidation4);

		Thread.sleep(1500);

		driver.findElement(By.id("AFEmail")).clear();
		driver.findElement(By.id("AFEmail")).sendKeys("sriramkumar470#");
		robo.keyPress(KeyEvent.VK_TAB);
		robo.keyRelease(KeyEvent.VK_TAB);
		WebElement email4 = driver.findElement(By.id("AFEmail-error"));
		String mailvalidation5 = email4.getText();
		String mailverify5 = "Please enter a valid email id";
		Assert.assertEquals(mailverify5, mailvalidation5);

		Thread.sleep(1500);

		driver.findElement(By.id("AFEmail")).clear();
		driver.findElement(By.id("AFEmail")).sendKeys("sriramkumar470@");
		robo.keyPress(KeyEvent.VK_TAB);
		robo.keyRelease(KeyEvent.VK_TAB);
		WebElement email5 = driver.findElement(By.id("AFEmail-error"));
		String mailvalidation6 = email5.getText();
		String mailverify6 = "Please enter a valid email id";
		Assert.assertEquals(mailverify6, mailvalidation6);

		Thread.sleep(1500);

		driver.findElement(By.id("AFEmail")).clear();
		driver.findElement(By.id("AFEmail")).sendKeys("sriramkumar470@gmail.com");
		System.out.println("email id");
		robo.keyPress(KeyEvent.VK_TAB);
		robo.keyRelease(KeyEvent.VK_TAB);

		// DOB

		driver.findElement(By.id("AFDob")).sendKeys("31011998");
		robo.keyPress(KeyEvent.VK_TAB);
		robo.keyRelease(KeyEvent.VK_TAB);
		WebElement dob = driver.findElement(By.id("AFDob-error"));
		String dobvalidation1 = dob.getText();
		String dobverify1 = "Please enter a valid date of birth";
		Assert.assertEquals(dobverify1, dobvalidation1);

		Thread.sleep(1500);

		driver.findElement(By.id("AFDob")).clear();
		driver.findElement(By.id("AFDob")).sendKeys("01-31-1998");
		robo.keyPress(KeyEvent.VK_TAB);
		robo.keyRelease(KeyEvent.VK_TAB);
		WebElement dob1 = driver.findElement(By.id("AFDob-error"));
		String dobvalidation2 = dob1.getText();
		String dobverify2 = "Please enter a valid date of birth";
		Assert.assertEquals(dobverify2, dobvalidation2);

		Thread.sleep(1500);

		driver.findElement(By.id("AFDob")).clear();
		driver.findElement(By.id("AFDob")).sendKeys("31-01-1998");
		System.out.println("date of birth");

		Thread.sleep(1500);

		driver.findElement(By.id("AFGenderMale")).click();
		driver.findElement(By.id("AFMaritalSingle")).click();

		Thread.sleep(1500);

		driver.findElement(By.id("AFGenderMale")).click();
		Thread.sleep(1000);

		driver.findElement(By.id("AFMaritalSingle")).click();
		Thread.sleep(1000);

		driver.findElement(By.id("AFLiveLnStusChkNo")).click();
		Thread.sleep(1000);

		// PAN NUMBER

		driver.findElement(By.id("AFPAN")).sendKeys("3091526");
		robo.keyPress(KeyEvent.VK_TAB);
		robo.keyRelease(KeyEvent.VK_TAB);
		WebElement pannumber = driver.findElement(By.id("AFPAN-error"));
		String panvalidation1 = pannumber.getText();
		String panverify1 = "Please enter a valid PAN number";
		Assert.assertEquals(panverify1, panvalidation1);

		Thread.sleep(1500);

		driver.findElement(By.id("AFPAN")).clear();
		driver.findElement(By.id("AFPAN")).sendKeys("lwrps m ");
		robo.keyPress(KeyEvent.VK_TAB);
		robo.keyRelease(KeyEvent.VK_TAB);
		WebElement pannumber1 = driver.findElement(By.id("AFPAN-error"));
		String panvalidation2 = pannumber1.getText();
		String panverify2 = "Please enter a valid PAN number";
		Assert.assertEquals(panverify2, panvalidation2);

		Thread.sleep(1500);

		driver.findElement(By.id("AFPAN")).clear();
		driver.findElement(By.id("AFPAN")).sendKeys("LWRPS3091 ");
		robo.keyPress(KeyEvent.VK_TAB);
		robo.keyRelease(KeyEvent.VK_TAB);
		WebElement pannumber2 = driver.findElement(By.id("AFPAN-error"));
		String panvalidation3 = pannumber2.getText();
		String panverify3 = "Please enter a valid PAN number";
		Assert.assertEquals(panverify3, panvalidation3);

		Thread.sleep(1500);
		driver.findElement(By.id("AFPAN")).clear();
		driver.findElement(By.id("AFPAN")).sendKeys("LWRPS3091M ");
		System.out.println("PAN number ");

		Thread.sleep(1500);

		// PIN CODE

		driver.findElement(By.id("AFResidencePincode")).sendKeys("sdsdssd");
		robo.keyPress(KeyEvent.VK_TAB);
		robo.keyRelease(KeyEvent.VK_TAB);
		WebElement pincode = driver.findElement(By.id("AFResidencePincode-error"));
		String pinvalidation1 = pincode.getText();
		String pinverify1 = "Please enter the pincode";
		Assert.assertEquals(pinverify1, pinvalidation1);

		Thread.sleep(1500);

		driver.findElement(By.id("AFResidencePincode")).clear();
		driver.findElement(By.id("AFResidencePincode")).sendKeys("656565");
		robo.keyPress(KeyEvent.VK_TAB);
		robo.keyRelease(KeyEvent.VK_TAB);
		WebElement pincode1 = driver.findElement(By.id("AFResidencePincode-error"));
		String pinvalidation2 = pincode1.getText();
		String pinverify2 = "Please enter the pincode";
		Assert.assertNotEquals(pinverify2, pinvalidation2);
		System.out.println("assert equal should happen");

		Thread.sleep(1500);

		// residence and city

		driver.findElement(By.id("AFResidencePincode")).clear();
		driver.findElement(By.id("AFResidencePincode")).sendKeys("632002");
		robo.keyPress(KeyEvent.VK_TAB);
		robo.keyRelease(KeyEvent.VK_TAB);

		WebElement residence = driver.findElement(By.id("AFResidenceCity"));
		String city = residence.getText();
		String citypresent = "";
		Assert.assertEquals(citypresent, city);

		Thread.sleep(2000);

		// I AGREE

		driver.findElement(By.xpath("//*[@id=\"qkPersonaldetsubmitForm\"]/div[8]/div[1]/div/label/span")).click();

		Thread.sleep(2000);

		// SUBMIT

		driver.findElement(By.xpath("//*[@id=\"qkPersonaldetsubmitForm\"]/div[8]/div[2]/div/button")).click();

		Thread.sleep(5000);

		// OTP

		driver.findElement(By.id("AFotpCode")).sendKeys("11111");

		driver.findElement(By.xpath("//*[@id=\"exampleModal\"]/div/div/div/div/div[2]/div/div[3]/button")).click();

		Thread.sleep(15000);

	}

	@Test(priority = 3)

	public void PAGE2() throws InterruptedException, IOException {

		Thread.sleep(1500);

		JavascriptExecutor js1 = (JavascriptExecutor) driver;
		js1.executeScript("window.scrollBy(0,150)", "");

		driver.findElement(By.xpath("//*[@id=\"ResidentialdetsubmitForm\"]/div[4]/div[2]/button")).click();
		System.out.println("submit clicked");

		WebElement page2submit = driver.findElement(By.id("AFManufacturer-error"));
		String page2error = page2submit.getText();
		String page2error1 = "Please select the manufacturer";
		Assert.assertEquals(page2error1, page2error);

		Thread.sleep(1500);

		Select manufacturer = new Select(driver.findElement(By.id("AFManufacturer")));
		manufacturer.selectByValue("HERO ELECTRIC");

		Thread.sleep(1500);

		Select mfmodel = new Select(driver.findElement(By.id("AFModel")));
		mfmodel.selectByValue("DASH");

		Thread.sleep(1500);

		Select Tenure = new Select(driver.findElement(By.id("AFTenure")));
		Tenure.selectByValue("18");

		Thread.sleep(1500);

		Select AFTimeTaken = new Select(driver.findElement(By.id("AFTimeTaken")));
		AFTimeTaken.selectByValue("immediate");

		Thread.sleep(1500);

		Select ResidentType = new Select(driver.findElement(By.id("AFResidentType")));
		ResidentType.selectByValue("Ownedbyselforspouse");

		Thread.sleep(1500);

		Select Currentlvgresidence = new Select(driver.findElement(By.id("AFCurrentlvgresidence")));
		Currentlvgresidence.selectByValue("bwn3to5");

		driver.findElement(By.xpath("//*[@id=\"ResidentialdetsubmitForm\"]/div[4]/div[2]/button")).click();

		Thread.sleep(7000);

		Select EmploymentType = new Select(driver.findElement(By.id("AFEmploymentType")));
		EmploymentType.selectByValue("Salaried");

		Thread.sleep(2000);

		Select OrgType = new Select(driver.findElement(By.id("AFOrgType")));
		OrgType.selectByValue("Private");

		Thread.sleep(2000);

		driver.findElement(By.id("AFNetMonthSalary")).sendKeys("50001");

		Thread.sleep(2000);

		driver.findElement(By.id("AFCompanyName")).sendKeys("control print limited");

		Thread.sleep(2000);

		Select noofyears = new Select(driver.findElement(By.id("AFNoofyearsworkCurtEmp")));
		noofyears.selectByValue("5");

		Thread.sleep(2000);

		Select totalworkexp = new Select(driver.findElement(By.id("AFTotalWorkExperience")));
		totalworkexp.selectByValue("5");

		Thread.sleep(2000);

		driver.findElement(By.id("AFExistingEmiCmts")).sendKeys("0");

		Thread.sleep(1500);

		JavascriptExecutor js3 = (JavascriptExecutor) driver;
		js3.executeScript("window.scrollBy(0,150)", "");

		driver.findElement(By.id("PaymentDPminimum")).click();

		Thread.sleep(1500);

		WebElement downpay = driver.findElement(By.id("AFDownPayment"));
		String amount = downpay.getText();
		String dispamount = "";
		Assert.assertEquals(dispamount, amount);

		Thread.sleep(1500);

		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,200)", "");

		driver.findElement(By.xpath("//*[@id=\"EmployerdetsubmitForm\"]/div[8]/div[2]/button")).click();
		System.out.println("page navigated to bank details page ");

		Thread.sleep(5000);

		driver.findElement(By.id("incomeproof")).sendKeys("C:\\Users\\DELL\\Downloads\\statement.pdf");

		Thread.sleep(13000);

		driver.findElement(By.id("AFIncomeProofPwd")).sendKeys("24509767");

		 driver.findElement(By.xpath("//*[@id=\"incomeproofpwdagain\"]")).click();

		Thread.sleep(65000);
		
		JavascriptExecutor js4 = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,250)", "");

		Thread.sleep(1500);
		
		

		driver.findElement(By.id("identityproof")).sendKeys("C:\\Users\\Public\\Pictures\\Sample Pictures\\desert.jpg");

		Thread.sleep(1500);

		driver.findElement(By.id("addressprooffront"))
				.sendKeys("C:\\Users\\Public\\Pictures\\Sample Pictures\\desert.jpg");

		Thread.sleep(1500);

		driver.findElement(By.id("addressproofback"))
				.sendKeys("C:\\Users\\Public\\Pictures\\Sample Pictures\\desert.jpg");

		Thread.sleep(2000);

		driver.findElement(By.xpath("//*[@id=\"DocumentsubmitForm\"]/div[4]/div[2]/button")).click();

		Thread.sleep(20000);


		Thread.sleep(10000);
		
		fun.capturescreenshot(driver);
	}

	@AfterTest

	public void END() {

		extentreport.flush();

		driver.close();
		driver.quit();
		System.out.println("driverclosed");
	}

}
