package Pageflow;

import java.io.FileInputStream;
import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;


public class excelreader {
	public static BasicFunction fun = new BasicFunction();


	String[][] data = null;

	@DataProvider(name = "Loginpage")
	public String[][] startingDataProvider() throws BiffException, IOException {
		
		data=getexcel();
		
		return data;

	}

	public String[][] getexcel() throws BiffException, IOException {

		FileInputStream ecxel = new FileInputStream("C:\\Users\\DELL\\Desktop\\readexcell.xls");
        
	
		
		Workbook workbook = Workbook.getWorkbook(ecxel);

		Sheet sheet = workbook.getSheet(0);

		int rowcount = sheet.getRows();
		int columncount = sheet.getColumns();

		String testData[][] = new String[rowcount - 1][columncount];

		for (int i = 1; i < rowcount; i++) {
			for (int j = 0; j < columncount; j++) {
				testData[i - 1][j] = sheet.getCell(j, i).getContents();

			}
		}

		return testData;

	}

 WebDriver driver;
	@BeforeTest

	public void openchrome() {
		System.setProperty("webdriver.chrome.driver", "E:\\chromedriver\\chromedriver.exe");
		this.driver = new ChromeDriver();
		driver.get("https://opensource-demo.orangehrmlive.com/");
		driver.manage().window().maximize();
	}


@Test(dataProvider="Loginpage")
public void login (String username,String Password) throws IOException {
	
	driver.findElement(By.id("txtUsername")).sendKeys(username);
	
	driver.findElement(By.id("txtPassword")).sendKeys(Password);
	
	driver.findElement(By.id("btnLogin")).click();
	
	
	
	
}



@AfterTest


public void close () throws IOException {
	fun.capturescreenshot(driver);
	driver.close();
	driver.quit();
}
}











